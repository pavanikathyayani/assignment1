/**
 * 
 */
/**
 * @author 2134179
 *
 */
module assignment1 {
}